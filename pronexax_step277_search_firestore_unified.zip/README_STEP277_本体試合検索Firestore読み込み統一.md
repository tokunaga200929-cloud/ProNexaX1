# STEP277 本体が実際に読んでいる試合検索ファイルを特定してFirestore読み込み先を統一

## 結論

本体 `index.html` の試合検索タブは以下を iframe で読んでいました。

```html
pages/search/embed.html
```

そして `pages/search/embed.html` は、実際には以下のJSを読んでいました。

```html
../../scripts/search/search.js
```

つまり、以前確認していた `pages/search/script.js` だけを直しても、本体Vercel側では反映されない可能性がありました。

## 今回の修正

### 1. 本体iframeの読み込み先を確認・更新

`index.html` の試合検索iframeを以下に更新しました。

```html
pages/search/embed.html?v=step277-firestore-unified
```

### 2. すべての試合検索HTMLにFirestore統一ローダーを追加

対象:

- `pages/search/embed.html`
- `pages/search/index.html`
- `pages/search/search.html`

追加:

```html
<script src="../../scripts/firebase/search-firestore-unified-loader.js?v=step277"></script>
```

### 3. 新規追加ファイル

- `scripts/firebase/search-firestore-unified-loader.js`

このファイルは、どの試合検索HTMLが開かれても以下を行います。

- Firestore `tournaments` を読み込む
- `PNX_CMS_TOURNAMENTS`
- `PNX_CMS_PUBLIC_TOURNAMENTS_FOR_SEARCH`
- `PNX_CMS_SEARCH_SYNC_META`

へ保存
- 試合検索カードを再描画
- iframe親にも読み込み状態を通知

### 4. 両方の試合検索JSにSTEP277処理を追加

対象:

- `scripts/search/search.js`
- `pages/search/script.js`

どちらを本体が読んでも、Firestore読み込みと再描画が動くようにしました。

### 5. キャッシュ対策

古いJSを読まないように、各読み込みURLの `?v=` を `step277` に更新しました。

## 追加された確認関数

本体画面のConsoleで確認する場合:

```js
PNXStep277SearchFrameStatus()
```

試合検索iframe側で確認する場合:

```js
PNXStep277SearchFirestoreStatus()
```

ただし、基本はCMSのFirebase診断パネルで確認すればOKです。

## 確認手順

1. このZIPをGitHubへ上書き
2. GitHubへpush
3. Vercelのデプロイ成功を確認
4. Vercel URLを `?v=277` 付きで開く
5. CMSで大会保存
6. 本体へ再反映
7. Firebase診断で Firestore tournaments と本体表示条件OK を確認
8. Vercel本体の試合検索タブを開く
9. Firestoreに保存した大会が表示されるか確認

## 注意

Firestoreに大会が保存されていても、本体が古い `pages/search/embed.html` や古い `scripts/search/search.js` を読んでいると表示されません。
今回のSTEP277では、そのズレを潰すために、本体iframe・検索HTML・検索JSの読み込みを統一しています。
