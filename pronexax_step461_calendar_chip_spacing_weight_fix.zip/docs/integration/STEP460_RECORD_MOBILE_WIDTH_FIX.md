# STEP460 Record mobile width fix

- 記録モジュールの固定 `360px` + scaler 拡大縮小を解除。
- 本体 iframe の幅いっぱいに表示されるよう `.phone { width:100%; height:100dvh; }` に変更。
- 左右に余白が出る原因の `body` 中央寄せと `#scaler` transform を無効化。
- 本体下ナビと二重になるため、記録モジュール内の `.tabbar` を非表示。
