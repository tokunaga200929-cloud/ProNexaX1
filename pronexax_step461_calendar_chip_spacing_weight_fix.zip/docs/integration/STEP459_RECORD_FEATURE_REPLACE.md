# STEP459 Record feature replace

- アップロードされた `記録.zip` の分析画面HTMLを `pages/record/embed.html` に差し替え。
- 本体 `index.html` の記録 iframe 参照を `?v=step459-record-replace` に更新。
- 既存のカレンダー/試合検索/遠征/特集/マイページ構成は維持。
