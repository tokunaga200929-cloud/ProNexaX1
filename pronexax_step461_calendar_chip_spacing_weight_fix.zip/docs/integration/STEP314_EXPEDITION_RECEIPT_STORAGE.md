# STEP314 遠征 領収書画像Firebase Storage保存

## 内容
領収書画像をlocalStorage/Firestoreに画像本体として保存せず、Firebase Storageへ保存するように変更。

## 保存方針
- 画像本体: Firebase Storage
- 遠征データ: Firestore
- 領収書データに保持する項目:
  - imageName
  - imageStoragePath
  - imageDownloadUrl
- imageDataUrl は保存しない

## 確認
領収書画像を追加して保存後、Consoleに以下が出ればOK。

`[expedition] receipt image stored: cms-media/expeditions/...`
`[expedition] Firestore saved: users/{uid}/expeditions/{tournamentId}`

Firebase Storageでは `cms-media/expeditions/{tournamentId}/receipts/...` を確認。
