# STEP457 Expedition hotel image

- 遠征 > ホテル画面の「選択中の宿泊先」と詳細シートにホテル画像を追加。
- 画像アセットを `assets/images/expedition/hotels/hotel-yonago-washington-plaza.png` に追加。
- `expeditionData.hotel.selected.imageUrl` を追加し、カード/詳細シートで `<img>` 表示に変更。
- CSSで `object-fit: cover` を適用し、枠いっぱい綺麗に表示するよう調整。
