# STEP440 Expedition hide status bar

- 遠征モジュール上部に表示されていた疑似ステータスバー（9:41 / Wi-Fi / バッテリー）を非表示化。
- `renderStatusBar()` が空文字を返すように変更。
- 念のため CSS でも `.exp-statusbar` を完全非表示。
- 本体側の実機ステータスバーとは別の、アプリ内に描画していたモック表示だけを削除。
