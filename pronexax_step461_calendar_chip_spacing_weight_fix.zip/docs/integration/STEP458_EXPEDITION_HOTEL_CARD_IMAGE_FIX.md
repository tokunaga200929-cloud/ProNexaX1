# STEP458 Expedition hotel card image fix

- STEP457で詳細側の画像は入っていたが、ホテルカード側で出ないケースがあったため修正。
- `hotelImageUrl()` のfallbackを追加し、localStorageに古い宿泊先データが残っていても画像が出るようにした。
- 画像パスを既存の遠征画像と同じ `../../assets/...` に統一。
- `.hotel-selected-card .hotel-photo img` に強制表示CSSを追加。
