# STEP384 Expedition Hotel Integration

本体ZIP `pronexax_step359_calendar_longpress_swipe_safe.zip` をベースに、遠征モジュールをホテル機能完成寄りの STEP374 相当に差し替え。

## 方針
- 本体のカレンダー・試合検索・広告・マイページは触らない
- 遠征モジュールのみ差し替え
- 旧遠征モジュールは `legacy/expedition_step359_original/` にバックアップ
- ジム画面は未安定のため、今回の本体統合には入れず、ホテル機能を優先
- 本体側の iframe `pages/expedition/embed.html` の参照を `step384-hotel-integrated` に更新

## 統合した遠征機能
- 遠征トップ
- ホテル画面
- 楽天トラベル / Googleマップ検索リンク
- 宿泊先 手動追加 / 編集
- ホテル詳細
- 宿泊費カテゴリ反映
- ホテル領収書 追加 / 一覧 / 削除 / 編集

## 注意
- ジム画面は Claude 作成後の `pronexax_step383_gym_screen_rebuild_by_claude.zip` または後続版で差し替える想定。
