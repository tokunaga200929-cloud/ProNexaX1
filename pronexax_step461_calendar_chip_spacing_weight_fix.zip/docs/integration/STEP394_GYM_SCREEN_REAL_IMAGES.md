# STEP394 Gym Screen Real Images

- STEP393をベースに、ジム画面をさらに参考イメージ寄りに微調整
- カードサイズ、余白、文字サイズ、ボタンサイズを調整
- ジム3件に画像アセットを追加
  - Anytime Fitness 米子東福原店
  - FIT365 米子東福原
  - ゴールドジム 米子エリア
- 画像は assets/images/expedition/gyms/ に保存
- 値段表示は引き続きなし
