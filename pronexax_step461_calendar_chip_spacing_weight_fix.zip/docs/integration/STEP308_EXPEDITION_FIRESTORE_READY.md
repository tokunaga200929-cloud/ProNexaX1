# STEP308 遠征データ構造整理 + Firestore保存準備

## 目的
遠征機能のデータが増えてきたため、Firestoreへ移行しやすい保存構造に整理したステップです。

## 今回の方針
まだFirestoreへ完全保存はしていません。
既存のlocalStorage保存を残したまま、保存/読み込み処理を `ExpeditionRepository` に集約しました。

## 追加・整理した内容
- `schemaVersion`
- `userId`
- `tournamentId`
- `travel`
- `hotel`
- `checklist`
- `expenses`
- `receipts`
- `memo`
- `createdAt`
- `updatedAt`
- 領収書画像用の将来項目
  - `imageStoragePath`
  - `imageDownloadUrl`

## Firestore想定パス
`users/{userId}/expeditions/{tournamentId}`

## Storage想定パス
`users/{userId}/expeditions/{tournamentId}/receipts/{receiptId}`

## 安全性
- 既存のUI/機能は変更しない
- localStorage保存は継続
- Firestoreが未接続でも動く
- `window.PNXExpeditionStorage.repository` から保存構造を参照可能
