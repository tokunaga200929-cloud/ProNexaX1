# STEP416 Search Calendar Add Fit

- 試合検索カードの「カレンダーに追加」ボタンで、スマホ表示時に「加」が欠ける問題を修正
- レイアウト構成は変えず、フッター内のCTAを可変幅化
- ボタン・URLピル・募集状態ピルの余白と文字サイズを微調整して自然に収まるようにした
- `pages/search/style.css` と `styles/search/search.css` の両方に同内容を適用
