# STEP424 Calendar 15-minute step

- クイックタイム画面の時間選択刻みを 30分 → 15分 に変更
- `quickTime.minuteStep` の初期値を 15 に変更
- `addDraft.minuteStep` の初期値も 15 に設定
- クイックタイム起動時のフォールバックも 15分刻みに統一
