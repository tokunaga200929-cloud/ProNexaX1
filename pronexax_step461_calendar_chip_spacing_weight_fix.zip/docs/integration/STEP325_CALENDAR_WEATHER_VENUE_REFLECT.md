# STEP325 カレンダー天気カード 会場名反映強化

## 内容
予定がある日の会場名を天気カードへ反映しやすくした。

## 会場名の取得優先順位
1. 画面上の予定カード `.pnx-cal-event-place span`
2. 選択日の保存イベント `loc / venue / course`
3. `rawTournament.venue / rawTournament.course`
4. タイトルにゴルフ場名らしい文字がある場合
5. 何もない場合は「現在地周辺」

## 確認ログ
`[ProNexaX Calendar] STEP325 WEATHER VENUE REFLECT LOADED`

## 手動確認
```js
PNXCalendarWeatherBridge.getVenue()
PNXCalendarWeatherBridge.getSelectedEvents()
PNXCalendarWeatherBridge.render()
```
