# STEP443 Expedition unselect hotel

- 遠征トップのカテゴリで「ホテル」が常に選択状態になっていた原因を修正。
- `expeditionData.categories` の hotel から `active: true` を削除。
- 遠征トップではカテゴリが未選択状態で表示されるように調整。
