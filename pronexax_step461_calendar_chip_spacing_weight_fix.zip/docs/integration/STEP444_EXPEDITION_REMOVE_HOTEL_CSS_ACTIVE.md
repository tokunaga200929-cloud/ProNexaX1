# STEP444 Expedition remove hotel CSS active

- STEP443ではJSデータの `active: true` は外したが、CSS側に `exp-cat[data-key="hotel"]` をアクティブ扱いする指定が残っていた。
- そのため見た目上ホテルだけ選択状態のまま残っていた。
- 今回は CSS のホテル強制アクティブ指定を削除。
- さらに安全策として、トップ画面では `c.active` があってもカテゴリに `is-active` を付けないようにした。
