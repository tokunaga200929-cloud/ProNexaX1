# STEP333 SEARCH CATEGORY SHEET UI POLISH

## 変更内容
- 試合検索の「カテゴリを選ぶ」Bottom Sheet をiPhone風UIに調整
- 絵文字アイコンをやめてSF Symbols風の線アイコンへ変更
- 右側の操作を「件数 / お気に入り / 追加」へ整理
- 追加済み状態を青ベースの見た目で明確化
- 完了ボタンも青ベースに統一

## 主な変更ファイル
- `styles/search/search.css`
- `scripts/search/search.js`
- `pages/search/style.css`
- `pages/search/script.js`

## 確認ポイント
1. 試合検索画面でフィルターボタン→カテゴリ追加シートを開く
2. 各カテゴリの左側が線アイコンになっていること
3. 「追加」を押すと青い「追加済」に変わること
4. ハートを押すとお気に入り見た目が切り替わること
5. 「完了」ボタンが青系で表示されること
