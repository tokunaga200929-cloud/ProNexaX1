# STEP313 遠征保存・復元安定化

## 内容
遠征データの保存状態を確認しやすくし、localStorage / Firestore の保存メタ情報を追加。

## 追加したもの
- 詳細画面に小さな保存状態カード
- 保存先Firestoreパスの確認ボタン
- localStorage保存ログ
- Firestore保存成功/失敗ログ
- `pnx-expedition-{tournamentId}-save-meta` に保存メタ情報を保存
- `window.PNXExpeditionStorage.debugMeta(data)`
- `window.PNXExpeditionStorage.debugPath(data)`

## 確認
遠征詳細でメモ等を編集して保存。
Consoleで以下が出ればOK。

`[expedition] local saved: ...`
`[expedition] Firestore saved: users/{uid}/expeditions/{tournamentId}`

Firestore未接続時でも端末保存は継続します。
