# STEP417 Calendar Date/Time Picker Reset

- カレンダー予定作成の日時指定・時間指定ホイールが、別画面移動後に残る問題を修正
- 予定作成を開く前に `resetDateTimePickerState()` で前回の日時指定シートを完全リセット
- 予定作成シートを閉じる時も日時指定シートを強制的に閉じる
- 下部ナビで別画面へ移動する前に、追加シート・詳細シート・日時指定シート・月ピッカーを閉じる
- 本体 `index.html` の画面切替側にも `PNXCalendarResetTransientPanels()` を追加し、カレンダー外のナビから移動した場合も残留しないようにした
