# STEP409 Gourmet Photo Clean

- グルメカード画像を承認済みモックから写真部分だけできれいに切り出し直し
- 1枚目のカフェ画像に混ざっていたUI部分を除去
- 画像表示を `object-fit: cover` / `object-position: center` で安定表示に調整
