# STEP326 カレンダー天気カード タイトル会場名反映修正

## 原因
予定データの `loc` が空で、ゴルフ場名が `title` に入っている場合、STEP325では会場名として拾えなかった。

## 修正
- 選択日のイベントタイトルからゴルフ場名らしい文字列を検出
- 対象キーワード:
  - ゴルフ
  - カンツリー
  - 倶楽部
  - クラブ
  - CC / ＣＣ
  - コース
  - GOLF / COUNTRY / CLUB / COURSE
- `loc` が空でも `title: "烏山城カントリークラブ"` のような予定を会場として使う

## 確認ログ
`[ProNexaX Calendar] STEP326 WEATHER TITLE VENUE FIX LOADED`

## 手動確認
```js
PNXCalendarWeatherBridge.getVenue()
PNXCalendarWeatherBridge.getSelectedEvents()
PNXCalendarWeatherBridge.venueFromEventTitle(PNXCalendarWeatherBridge.getSelectedEvents()[3])
PNXCalendarWeatherBridge.render()
```
