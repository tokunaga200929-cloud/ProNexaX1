# STEP414 Featured TFW Background Keep Text

- 注目ページ先頭の大きい広告バナーについて、既存テキスト・CTAは維持したまま背景画像のみTFWウェア画像へ差し替え
- ユーザー提供画像から服とズボンのビジュアルだけを活かした背景アセット `tfw-spring-hero-bg-only.png` を作成
- 服のTFWロゴはそのまま残し、バナー左側の文字の可読性を保つため overlay を微調整
