/* =========================================================================
   STEP328: ProNexaX Calendar Weather Component Bridge
   予定がある日の会場名を天気カードへ確実に反映。
   ========================================================================= */
(function PNXCalendarWeatherBridge() {
  'use strict';

  var lastSignature = '';
  var initialized = false;

  function ready(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn, { once: true });
    } else {
      fn();
    }
  }

  function safeText(el) {
    return el && el.textContent ? el.textContent.trim() : '';
  }

  function firstValue() {
    for (var i = 0; i < arguments.length; i += 1) {
      var v = arguments[i];
      if (v !== undefined && v !== null && String(v).trim() !== '') return String(v).trim();
    }
    return '';
  }

  function parseSheetDateText(text) {
    var now = new Date();
    var m = String(text || '').match(/(\d{1,2})月(\d{1,2})日/);
    if (!m) return [
      now.getFullYear(),
      String(now.getMonth() + 1).padStart(2, '0'),
      String(now.getDate()).padStart(2, '0')
    ].join('-');
    return [
      now.getFullYear(),
      String(Number(m[1])).padStart(2, '0'),
      String(Number(m[2])).padStart(2, '0')
    ].join('-');
  }

  function parseDatePartsFromSheet() {
    var text = safeText(document.querySelector('[data-pnx-sheet-date]'));
    var now = new Date();
    var m = String(text || '').match(/(\d{1,2})月(\d{1,2})日/);
    return {
      y: now.getFullYear(),
      m: m ? Number(m[1]) : now.getMonth() + 1,
      d: m ? Number(m[2]) : now.getDate(),
      text: text
    };
  }

  function readCalendarEvents() {
    var keys = [
      'pronexax.calendar.v2.events.step203',
      'PNX_CALENDAR_EVENTS',
      'pronexax.calendar.events'
    ];
    for (var i = 0; i < keys.length; i += 1) {
      try {
        var parsed = JSON.parse(localStorage.getItem(keys[i]) || 'null');
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  }

  function eventStart(e) {
    return { y: Number(e && e.y), m: Number(e && e.m), d: Number(e && e.d) };
  }

  function eventEnd(e) {
    return {
      y: Number((e && e.endY) || (e && e.y)),
      m: Number((e && e.endM) || (e && e.m)),
      d: Number((e && e.endD) || (e && e.d))
    };
  }

  function compareDate(a, b) {
    var aa = a.y * 10000 + a.m * 100 + a.d;
    var bb = b.y * 10000 + b.m * 100 + b.d;
    return aa === bb ? 0 : (aa > bb ? 1 : -1);
  }

  function isDateInEvent(date, e) {
    if (!e || !e.y || !e.m || !e.d) return false;
    return compareDate(date, eventStart(e)) >= 0 && compareDate(date, eventEnd(e)) <= 0;
  }

  function eventsForSelectedDate() {
    var date = parseDatePartsFromSheet();
    return readCalendarEvents().filter(function(e) {
      return isDateInEvent(date, e);
    });
  }

  function venueFromEvent(event) {
    var raw = event && event.rawTournament ? event.rawTournament : {};
    var course = firstValue(
      event && event.loc,
      event && event.venue,
      event && event.course,
      raw.venue,
      raw.course,
      raw.place,
      raw.golfCourse,
      raw.venueName
    );
    var pref = firstValue(event && event.prefecture, raw.prefecture);
    if (course && pref && course.indexOf(pref) === -1) return course + '（' + pref + '）';
    return course;
  }

  function looksLikeGolfVenue(text) {
    var value = String(text || '').trim();
    if (!value) return false;
    return /ゴルフ|カンツリー|倶楽部|クラブ|CC|ＣＣ|コース|GOLF|COUNTRY|CLUB|COURSE/i.test(value);
  }

  function cleanVenueTitle(text) {
    var value = String(text || '').trim();
    if (!value) return '';

    // 画面上の省略記号は消す
    value = value.replace(/…+$/g, '').trim();

    // 予定タイトルとして入った余計な語尾を軽く除去
    value = value
      .replace(/でラウンド$/g, '')
      .replace(/ラウンド$/g, '')
      .replace(/練習ラウンド$/g, '')
      .replace(/予定$/g, '')
      .trim();

    return value;
  }

  function venueFromEventTitle(event) {
    if (!event) return '';
    var raw = event.rawTournament || {};
    var candidates = [
      event.title,
      event.chipLabel,
      event.chipLines && event.chipLines[0],
      raw.venue,
      raw.course,
      raw.title,
      raw.name
    ];

    for (var i = 0; i < candidates.length; i += 1) {
      var value = cleanVenueTitle(candidates[i]);
      if (looksLikeGolfVenue(value)) return value;
    }
    return '';
  }

  function getVenue() {
    // 1. 表示済み予定カードの場所表示を優先
    var visiblePlace = safeText(document.querySelector('.pnx-cal-event-place span'));
    if (visiblePlace) return visiblePlace;

    // 2. 選択日の保存イベントから会場を探す
    var events = eventsForSelectedDate();

    // 大会系を優先: loc / venue / rawTournament.course
    for (var i = 0; i < events.length; i += 1) {
      var e = events[i];
      var isTournament =
        e && (e.category === 'tournament' || e.kind === 'tournament' || e.source === 'search-module' || e.tournamentId || e.rawTournament);
      var venue = venueFromEvent(e);
      if (isTournament && venue) return venue;
    }

    // 通常予定でも loc / venue / course があれば採用
    for (var j = 0; j < events.length; j += 1) {
      var venue2 = venueFromEvent(events[j]);
      if (venue2) return venue2;
    }

    // STEP326:
    // locが空でも、予定タイトル自体が「烏山城カントリークラブ」などゴルフ場名なら会場として使う。
    // 複数予定がある場合は、ゴルフ場っぽいタイトルを優先。
    for (var k = 0; k < events.length; k += 1) {
      var venue3 = venueFromEventTitle(events[k]);
      if (venue3) return venue3;
    }

    // 3. 画面上の表示タイトル全部からも探す
    var titles = Array.prototype.slice.call(document.querySelectorAll('.pnx-cal-event-title'));
    for (var t = 0; t < titles.length; t += 1) {
      var title = cleanVenueTitle(safeText(titles[t]));
      if (looksLikeGolfVenue(title)) return title;
    }

    return '現在地周辺';
  }

  function ensureRoot() {
    var sheet = document.querySelector('.pnx-cal-sheet');
    if (!sheet) return null;

    var slot = sheet.querySelector('[data-pnx-weather-slot]');
    if (!slot) {
      var list = sheet.querySelector('[data-pnx-sheet-list]');
      if (!list) return null;
      slot = document.createElement('div');
      slot.className = 'pnx-cal-weather-component-slot';
      slot.setAttribute('data-pnx-weather-slot', '');
      slot.innerHTML = '<div id="pnx-weather-card-root"></div>';
      list.insertAdjacentElement('afterend', slot);
    }

    var root = slot.querySelector('#pnx-weather-card-root');
    if (!root) {
      root = document.createElement('div');
      root.id = 'pnx-weather-card-root';
      slot.appendChild(root);
    }
    return root;
  }

  function getSelectedWeatherContext() {
    var events = eventsForSelectedDate();
    var venue = getVenue();
    var selected = null;

    for (var i = 0; i < events.length; i += 1) {
      var e = events[i];
      if (venueFromEvent(e) === venue || venueFromEventTitle(e) === venue) {
        selected = e;
        break;
      }
    }
    if (!selected && events.length) selected = events[0];

    var raw = selected && selected.rawTournament ? selected.rawTournament : {};
    return {
      venue: venue,
      venueLat: firstValue(selected && selected.venueLat, selected && selected.lat, raw.venueLat, raw.lat, raw.latitude),
      venueLng: firstValue(selected && selected.venueLng, selected && selected.lng, selected && selected.lon, raw.venueLng, raw.lng, raw.lon, raw.longitude),
      prefecture: firstValue(selected && selected.prefecture, raw.prefecture),
      weatherProvider: "mock",
      sourceLabel: "テスト天気"
    };
  }

  function renderWeather(force) {
    var root = ensureRoot();
    if (!root || !window.PNXWeatherCard) return false;

    var dateText = safeText(document.querySelector('[data-pnx-sheet-date]'));
    var date = parseSheetDateText(dateText);
    var context = getSelectedWeatherContext();
    var venue = context.venue;

    var signature = date + '|' + venue + '|' + (context.venueLat || '') + '|' + (context.venueLng || '');
    if (!force && initialized && signature === lastSignature) return true;
    lastSignature = signature;

    var data = window.PNXWeatherCard.getDummyData
      ? window.PNXWeatherCard.getDummyData(date)
      : {};

    data = Object.assign({}, data, context, {
      date: date,
      weatherDate: date,
      venue: venue || data.venue || '現在地周辺',
      weatherUpdatedAt: new Date().toISOString(),
      isMock: true
    });

    if (!initialized && window.PNXWeatherCard.init) {
      window.PNXWeatherCard.init({
        rootId: 'pnx-weather-card-root',
        data: data
      });
      initialized = true;
    } else if (window.PNXWeatherCard.setData) {
      window.PNXWeatherCard.setData(data);
      initialized = true;
    }

    return true;
  }

  function scheduleRender(delay, force) {
    setTimeout(function () { renderWeather(!!force); }, delay || 0);
  }

  ready(function () {
    console.info('[ProNexaX Calendar] STEP328 WEATHER API READY SCHEMA LOADED');

    scheduleRender(100, true);
    scheduleRender(500, true);
    scheduleRender(1200, true);

    document.addEventListener('click', function (event) {
      if (
        event.target.closest('.pnx-cal-cell') ||
        event.target.closest('[data-pnx-action="today"]') ||
        event.target.closest('[data-pnx-action="prev-month"]') ||
        event.target.closest('[data-pnx-action="next-month"]') ||
        event.target.closest('[data-pnx-action="month-picker-prev-year"]') ||
        event.target.closest('[data-pnx-action="month-picker-next-year"]') ||
        event.target.closest('[data-pnx-event-id]')
      ) {
        lastSignature = '';
        scheduleRender(80, true);
        scheduleRender(260, true);
      }
    }, true);

    var root = document.querySelector('.pnx-calendar-v2') || document.body;
    var timer = null;
    var obs = new MutationObserver(function () {
      clearTimeout(timer);
      timer = setTimeout(function () {
        if (document.querySelector('[data-pnx-sheet-list]')) renderWeather(false);
      }, 160);
    });

    obs.observe(root, { childList: true, subtree: true, characterData: true });

    window.PNXCalendarWeatherBridge = {
      render: function () {
        lastSignature = '';
        return renderWeather(true);
      },
      getVenue: getVenue,
      getSelectedEvents: eventsForSelectedDate,
      venueFromEventTitle: venueFromEventTitle,
      getWeatherContext: getSelectedWeatherContext,
      getDate: function () {
        return parseSheetDateText(safeText(document.querySelector('[data-pnx-sheet-date]')));
      }
    };
  });
})();
