# ProNexaX STEP205 — CMS大会を試合検索へ反映

このZIPは `pronexax_step204_tournament_detail_sheet.zip` を基準に、CMS登録大会を本体の試合検索へ表示する連携を追加したものです。

## できること
- CMSで登録した公開大会を試合検索に表示
- 下書き/非公開大会は表示しない
- CMS大会も通常カードUIで表示
- CMS大会もカレンダー追加できる
- カレンダー追加後はSTEP204の大会詳細Bottom Sheetで確認できる

## 使うlocalStorageキー
- `PNX_CMS_PUBLIC_TOURNAMENTS_FOR_SEARCH`
- `PNX_CMS_TOURNAMENTS`
- `PNX_CMS_SEARCH_SYNC_META`
- `PNX_CMS_TOURNAMENTS_UPDATED_AT`

## デバッグ
試合検索画面のコンソールで以下を実行できます。

```js
PNXStep205CmsSearchStatus()
PNXStep205RefreshCmsTournaments()
```

## 注意
Firestore本接続ではなく、まずはCMSのlocalStorageスナップショットを試合検索に反映する段階です。
