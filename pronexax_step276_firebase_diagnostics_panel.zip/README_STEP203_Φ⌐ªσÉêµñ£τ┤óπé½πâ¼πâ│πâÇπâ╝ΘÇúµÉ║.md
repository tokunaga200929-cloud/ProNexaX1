# ProNexaX STEP203：試合検索 → 本体カレンダー追加連携

## 目的
STEP202で本体内に表示できるようになった試合検索モジュールから、実際に本体カレンダーへ大会予定を追加できるようにしました。

## 変更内容
- `scripts/search/search.js`
  - `handleCalendarAdd(id)` から親画面へ `postMessage` を送信
  - 送信タイプ：`PNX_ADD_TOURNAMENT_TO_CALENDAR`
  - 大会ID、名称、開催日、会場、主催、賞金、エントリー費、締切などを送信

- `index.html`
  - `PNX_ADD_TOURNAMENT_TO_CALENDAR` を受信する STEP203 listener を追加
  - 受信後、`window.PNXCalendarAddTournamentEvent(tournament)` を呼び出す

- `calendar.js`
  - `window.PNXCalendarAddTournamentEvent()` を追加
  - 大会データを本体カレンダーイベント形式へ変換
  - `tournament-{id}` で二重追加を防止
  - `localStorage` へ保存し、再読み込み後も予定を維持
  - 既存の手動予定追加・編集・削除後も保存されるように調整

- `pages/search/embed.html` / `pages/search/index.html`
  - 試合検索iframe内で重複スクリプト読み込みが起きないよう、使用スクリプトを `../../scripts/search/search.js` に統一

## 完成条件
1. `index.html` を開く
2. 下部ナビ「試合検索」を押す
3. 大会カードまたは詳細Bottom Sheetの「カレンダーに追加」を押す
4. 下部ナビ「カレンダー」に戻る
5. 大会が本体カレンダーに表示される
6. 同じ大会をもう一度追加しても重複しない
7. ページを再読み込みしても予定が残る
8. カレンダー側の削除機能は維持

## デバッグ用
ブラウザコンソールで以下を確認できます。

```js
PNXStep203SearchCalendarLinkStatus()
PNXCalendarGetEvents()
PNXStep201SmokeTest()
```
