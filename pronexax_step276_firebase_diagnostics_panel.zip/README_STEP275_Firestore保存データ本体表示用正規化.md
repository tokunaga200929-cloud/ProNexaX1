# STEP275 Firestore保存データを本体表示用に完全正規化

## 今回の原因

CMSでは登録できてFirestoreの `tournaments` にもデータは入っていました。
でも、本体試合検索が表示に必要とするフィールド名が不足・ズレている大会がありました。

本体表示に最低限必要な項目:

- `title` / `name`
- `startDate` / `start`
- `endDate` / `end`
- `venue` / `course`
- `category` / `cat`
- `status`
- `published`

Firestore上には `links.website` などネストされた形式で入っている項目もあり、本体側が直接見る `officialUrl` などにコピーされていないケースがありました。

## 修正内容

- Firestore保存時に本体表示用フィールドを必ず複製
- Firestore読み込み時も不足フィールドを補完
- `links.website` → `officialUrl`
- `links.entry` → `entryUrl`
- `links.instagram` → `instagramUrl`
- `links.result` → `resultUrl`
- `links.pairing` → `pairingUrl`
- `venue` と `course` を両方保存
- `category` と `cat` を両方保存
- `startDate` と `start` を両方保存
- `endDate` と `end` を両方保存
- `status: open` なら `published: true` 扱い
- Firestore読み込み時の `orderBy("startDate")` を廃止
  - `startDate` がない古いデータも読み込み、JS側で補正・並び替え

## 確認手順

1. このZIPをVercelに再アップ
2. CMSで大会を1つ開いて保存
3. 「本体へ反映」を押す
4. Firebaseの `tournaments` のドキュメントに以下があるか確認
   - `title`
   - `startDate`
   - `venue`
   - `category`
   - `status`
   - `published`
5. スマホでVercelの試合検索を開く
6. 登録大会が表示されるか確認

## 注意

すでにFirestoreに入っている古いドキュメントは、CMSで一度保存し直すか「本体へ反映」を押すと新しい形式に揃います。
