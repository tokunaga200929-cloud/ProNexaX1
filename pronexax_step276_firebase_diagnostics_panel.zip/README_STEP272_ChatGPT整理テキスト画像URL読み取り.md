# STEP272 ChatGPT整理テキストから画像URL / pnx-media を読み取る修正

## 修正理由

ChatGPTで大会情報を整理した文章をCMSに貼った時に、以下の項目が読み取られず空欄になる問題がありました。

- 大会ロゴURL
- 会場画像URL
- `pnx-media:media_xxx` 形式の画像参照

## 修正内容

- `pnx-media:` 形式をURL扱いで読み取り
- `大会ロゴURL` を `logoUrl / tournamentLogoUrl` に反映
- `会場画像URL` を `venueImageUrl / imageUrl / coverImageUrl` に反映
- `会場画像 / コース画像URL / ゴルフ場画像URL / メイン画像URL` などの表記にも対応
- 仮登録プレビューで画像とロゴが表示されるように調整
- 保存後も画像フィールドが残るように調整
- `ステータス：open` も読み取り、openなら公開対象として仮登録

## 今回の例

```txt
大会ロゴURL：pnx-media:media_1780008837010_9cwz1l
会場画像URL：https://www.keyagc.co.jp/wp2024/wp-content/themes/keyagc/images/index/mv01.jpg
```

上記を貼ると以下に入ります。

```js
logoUrl: "pnx-media:media_1780008837010_9cwz1l"
tournamentLogoUrl: "pnx-media:media_1780008837010_9cwz1l"
venueImageUrl: "https://www.keyagc.co.jp/wp2024/wp-content/themes/keyagc/images/index/mv01.jpg"
imageUrl: "https://www.keyagc.co.jp/wp2024/wp-content/themes/keyagc/images/index/mv01.jpg"
coverImageUrl: "https://www.keyagc.co.jp/wp2024/wp-content/themes/keyagc/images/index/mv01.jpg"
```
