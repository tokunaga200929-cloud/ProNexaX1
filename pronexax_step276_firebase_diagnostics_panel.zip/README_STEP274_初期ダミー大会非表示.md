# STEP274 初期ダミー大会を非表示化

## 修正理由

本体試合検索に、最初から入っている仮データ・ダミー大会カードが表示されていました。

例:
- 関東オープンゴルフ選手権競技
- Future Tour 第3戦 関東大会
- 日本ゴルフツアー選手権 森ビルカップ など

Firestore連携後は、実際にCMSで登録した大会だけを表示したいため、初期ダミー大会を非表示にしました。

## 修正内容

- `scripts/search/search.js`
- `pages/search/script.js`

上記2ファイルの `DUMMY_TOURNAMENTS` を空にしました。

## 表示ルール

今後の試合検索カードは以下のみ表示されます。

1. CMSで保存した大会
2. Firestoreの `tournaments` から読み込んだ大会
3. `status !== draft`
4. `published !== false`

## 注意

Firestoreにまだ大会が入っていない場合、試合検索には大会カードが表示されません。
その場合はCMSで大会を登録し、「本体へ反映」を押してください。
