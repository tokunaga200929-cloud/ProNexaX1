# STEP210 注目/広告ページのスクロール修正

## 修正内容
- 本体iframe内の「広告・注目」ページで下方向にスクロールできない問題を修正。
- 原因は embed.html 側で html/body を overflow:hidden にしている一方、.app-wrapper が min-height のみで固定高さになっておらず、.scroll-content が内部スクロール領域として成立していなかったこと。
- .app-wrapper を 100dvh の固定スクロールコンテナにし、.scroll-content に min-height:0 / height:100% / overflow-y:auto / -webkit-overflow-scrolling:touch を付与。
- 本体側の featured iframe cache key を step210-featured-scroll に更新。

## 触っていないもの
- カレンダー本体ロジック
- 試合検索→カレンダー追加連携
- 大会詳細Bottom Sheet
- CMS同期
- マイページ青テーマ
- 月スワイプ演出
