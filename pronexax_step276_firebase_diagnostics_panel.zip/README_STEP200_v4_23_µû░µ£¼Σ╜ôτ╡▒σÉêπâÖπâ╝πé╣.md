# STEP200 v4.23 新本体統合ベース

送ってもらった `pronexax_calendar_v2_FIXED_v4_23_apple_typography_tune.zip` を新しい本体として採用した統合ベースです。

## 目的

カレンダー本体を壊さずに、以下をスムーズに統合できるようにしました。

- 試合検索
- 収支
- 広告 / 注目
- マイページ
- プロフィール
- CMS

## 確認

ブラウザで `index.html` を開き、下部ナビから各ページに切り替わるか確認してください。

```js
PNXStep200IntegrationStatus()
```
