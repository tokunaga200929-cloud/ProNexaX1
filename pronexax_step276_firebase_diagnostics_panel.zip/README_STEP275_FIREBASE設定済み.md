# STEP275 Firebase設定済み版

このZIPでは、`scripts/firebase/firestore-config.js` にFirebase設定値を反映済みです。

## 重要

今後、新しいZIPを作るたびに `firestore-config.js` が初期状態に戻る可能性があります。
その場合は、必ずこの設定済みファイルを再利用するか、Firebase設定値を再度貼り付けてください。

## 次にやること

1. このZIPをVercelにアップ
2. デプロイ完了後にCMSを開く
3. 大会を1つ選んで保存
4. 「本体へ反映」を押す
5. Firebase Console の Firestore > tournaments を確認
6. `title`, `startDate`, `venue`, `category`, `status`, `published` が入っているか確認
7. スマホで本体試合検索を確認
