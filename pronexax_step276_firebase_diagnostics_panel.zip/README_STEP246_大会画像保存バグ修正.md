# STEP246 大会画像保存バグ修正

## 修正内容

STEP245で大会画像ファイルを選んでプレビュー表示まではできていましたが、保存時に画像が残らない問題がありました。

原因は、CMS画面上では `logoUrl` / `venueImageUrl` が入っていても、`saveTournament()` のBridge正規化処理で画像系フィールドが保存対象に含まれていなかったためです。

## 対応したこと

- `cms-final-design-bridge.js` の `normalizeTournament()` に画像系フィールドを追加
  - `logoUrl`
  - `tournamentLogoUrl`
  - `venueImageUrl`
  - `imageUrl`
  - `coverImageUrl`
  - `imageAssetId`
  - `logoAssetId`
  - `imageAlt`
- 本体反映用の検索スナップショットにも画像系フィールドを保持
- CMSの登録済み大会編集で、画像を選んだ時に alias フィールドも同期
  - `logoUrl` ↔ `tournamentLogoUrl`
  - `venueImageUrl` ↔ `imageUrl`
- 仮登録大会でも同じように画像系フィールドを同期
- 保存ボタンを押した後も、画像が登録済み大会データに残るように修正

## 確認してほしいこと

1. 登録済み大会管理で大会を選ぶ
2. 会場画像または大会ロゴをファイルから選ぶ
3. プレビューに画像が出る
4. 保存を押す
5. 再読み込みしても画像が残っているか確認
6. 公開/本体反映後に試合検索側でも画像が残るか確認
