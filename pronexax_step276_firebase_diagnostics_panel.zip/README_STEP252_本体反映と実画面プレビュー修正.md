# STEP252 本体反映と右側プレビュー実画面化

## 修正理由

STEP251で画像欄が消えなくなりましたが、次の問題が残っていました。

- 本体の試合検索に反映されない
- 右側プレビューが静止モックのままで、検索・タップ・詳細表示を確認できない

## 変更内容

### 1. 保存時の本体反映を強化

公開対象（下書き以外）の大会を保存した時に、検索用スナップショットだけでなく `pnxStep129SafePublishToApp()` も実行し、正式な本体反映データを書き出すようにしました。

画像フィールドも公開用データに明示的に保持します。

- `logoUrl`
- `tournamentLogoUrl`
- `venueImageUrl`
- `imageUrl`
- `coverImageUrl`
- `imageAssetId`
- `logoAssetId`
- `imageAlt`

### 2. 本体・検索iframeへの通知を強化

CMSが別タブで開いている場合でも反映されやすいよう、以下を追加しました。

- `window.postMessage`
- `window.opener.postMessage`
- `BroadcastChannel`
- 同一画面カスタムイベント
- `index.html` 側でCMSからの反映通知を試合検索iframeへ転送
- `search.js` 側でcustom event / BroadcastChannelも受信

### 3. 右側プレビューを実画面iframeに変更

CMS右側の試合検索プレビューを、Reactの静止モックではなく、実際の `pages/search/embed.html` を読み込むiframeに変更しました。

これにより、右側プレビュー内で以下を確認できます。

- 検索
- スクロール
- 大会カード表示
- カードタップ
- 詳細Bottom Sheet
- CMS保存済み画像の表示

## 確認手順

1. CMSで大会を選ぶ
2. 会場画像・大会ロゴを設定
3. ステータスを「募集中」にする
4. 保存
5. 右側プレビューで実際の試合検索画面に画像付きカードが出るか確認
6. 本体の試合検索を開く
7. 画像付き大会カードが反映されているか確認
