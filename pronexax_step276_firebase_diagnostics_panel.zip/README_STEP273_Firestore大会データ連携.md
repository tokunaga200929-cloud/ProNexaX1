# STEP273 Firestore大会データ連携

## 目的

PCブラウザのCMSで登録した大会が、スマホのVercel本体でも見えるようにするため、CMS保存と本体試合検索の読み込みをFirestore対応にしました。

## 追加ファイル

- `scripts/firebase/tournament-firestore-sync.js`
  - CMS保存大会をFirestoreへ保存
  - 本体試合検索でFirestoreから大会を読み込み
  - Firestoreが未設定の場合はlocalStorageにフォールバック

- `firebase/firestore.rules.example`
  - 開発用Firestore Rules例

## 修正内容

### CMS側

- 大会保存時に `tournaments` コレクションへ自動保存
- 大会削除時にFirestore側も削除
- 「本体へ反映」時にlocalStorageの大会一覧をFirestoreへ一括同期
- Firestore未設定の場合はこれまで通りlocalStorage保存

### 本体試合検索側

- 起動時にFirestoreの `tournaments` を読み込み
- `status !== draft` かつ `published !== false` の大会だけ表示対象
- Firestoreから読み込んだ内容を既存の試合検索カードへ合流
- スマホとPCで同じ大会データを見られる土台を追加

## 重要

このZIPだけではFirestore通信はまだ有効になりません。
`/scripts/firebase/firestore-config.js` の `YOUR_...` をFirebase Consoleの実値に差し替えてからVercelへデプロイしてください。

## 確認手順

1. Firebase ConsoleでWebアプリの設定値を取得
2. `scripts/firebase/firestore-config.js` に貼る
3. Firestore Databaseを作成
4. 開発中は `firebase/firestore.rules.example` を参考にRules設定
5. Vercelへデプロイ
6. CMSで大会を保存
7. 「本体へ反映」を押す
8. スマホでVercelの試合検索を開く
9. 登録大会カードが表示されるか確認

## 注意

本番ではFirestore Rulesを必ず管理者だけが書き込める形にしてください。
