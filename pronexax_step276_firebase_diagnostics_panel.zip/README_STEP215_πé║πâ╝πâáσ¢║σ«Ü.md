# STEP215 画面ズーム固定

- スマホでのピンチズームを無効化
- ダブルタップズームも抑制
- 各HTMLのviewportを `maximum-scale=1, user-scalable=no` に統一
- 共通スクリプト `scripts/disable-zoom.js` を追加
- 既存のカレンダー・試合検索・注目・収支・マイページの機能は維持
