# STEP222 PICK UPバナーCMS反映

- CMSのPICK UPバナー管理で編集した内容を、本体の注目ページ上部バナーへ反映
- 反映対象: ラベル / タイトル / 説明文 / ボタン文言 / リンク
- 本体側は `PNX_CMS_BANNERS` と `PNX_CMS_FEATURED_CONTENTS` を読み取り、公開中のPICK UPバナーを表示
- ボタンにリンクがある場合は外部リンクとして開く
- 素材がない時はSTEP219の表示設定でPICK UPバナー自体を非表示にできる
- PRカードCMS管理、ウェアカードCMS管理、青テーマは維持
