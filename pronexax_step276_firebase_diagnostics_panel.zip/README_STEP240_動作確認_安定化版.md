# STEP240 注目/広告CMS 動作確認・安定化版

## 目的

STEP239までで増えた注目/広告CMS機能を、一度テストしやすい状態に固めた版です。

## 追加内容

- かんたん編集画面に「動作確認チェック」パネルを追加
- 主要機能の状態をCMS上で確認しやすくした
- 確認項目から該当編集画面へ移動できるようにした
- NetlifyへそのままアップしやすいZIP構成を維持

## 確認したファイル

- OK: index.html
- OK: calendar.js
- OK: calendar.css
- OK: cms/index.html
- OK: cms/cms.js
- OK: cms/styles.css
- OK: pages/featured/embed.html
- OK: pages/featured/featured.html
- OK: scripts/featured/featured.js
- OK: styles/featured/featured.css
- OK: STEP223 right live preview
- OK: STEP229 draft publish
- OK: STEP231 preview toggle
- OK: STEP238 click edit
- OK: STEP239 image picker

## 手動確認してほしいこと

1. `index.html` を開いて本体アプリが表示されるか
2. `cms/index.html` を開いてCMSが表示されるか
3. ホーム（注目ページ）管理の「かんたん編集」が表示されるか
4. 右側プレビューを開閉できるか
5. プレビュー内をクリックして該当編集画面に移動できるか
6. PICK UP / ウェア / PR / 記事の画像URLを変更してプレビューに反映されるか
7. 画像ライブラリから画像を選んで反映できるか
8. 下書き保存と公開するが分かれているか
9. 公開前確認ダイアログが表示されるか
10. カレンダー・試合検索・マイページが壊れていないか

## 次に進むなら

- STEP241: メディアライブラリの見やすさ改善
- STEP242: 記事/PR/ウェアカードの追加・削除
- STEP243: 注目ページの並び替え
- STEP244: CMSデータのバックアップ/復元
