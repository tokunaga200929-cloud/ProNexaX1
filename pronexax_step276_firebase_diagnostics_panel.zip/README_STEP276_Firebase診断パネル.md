# STEP276 Firebase診断パネル追加

## 目的

Consoleを触らなくても、CMS画面上でFirebase / Firestore接続状態を確認できるようにしました。

## 追加ファイル

- `cms/cms-firebase-diagnostics-panel.js`

## cms/index.html の追加

以下を `cms-final-design-bridge.js` の直後に追加しています。

```html
<script src="cms-firebase-diagnostics-panel.js?v=step276"></script>
```

## CMS画面に出る内容

右下に「Firebase診断」パネルが表示されます。

表示内容:

- Firebase設定: OK / NG
- Firestore接続: OK / NG
- CMS内大会件数
- 本体表示スナップショット件数
- Firestore tournaments件数
- 本体表示条件OK件数
- 最終アクション
- 最終更新

## ボタン

### 接続チェック

Firebase設定とFirestore接続を確認します。

### Firestore読込

Firestoreの `tournaments` を読み込み、CMS / 本体表示スナップショットへ反映します。

### 本体へ再反映

CMS内の大会データをFirestoreへ再保存します。

## 使い方

1. このZIPをVercel / GitHubにアップ
2. CMS画面を開く
3. 右下のFirebase診断を見る
4. `Firebase設定 OK` / `Firestore接続 OK` になっているか確認
5. NGなら表示されるメッセージに従って修正
6. OKになったら、CMSで大会保存 → 本体へ再反映
7. Firestore tournaments件数と本体表示条件OK件数を確認

## 注意

今後新しいZIPを作るときも、`scripts/firebase/firestore-config.js` が初期値に戻っていないか確認してください。
