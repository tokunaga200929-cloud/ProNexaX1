#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
PORT=8787
URL="http://127.0.0.1:$PORT/index.html"
clear
echo "Px Golf Camera MVP v2 を起動中..."
python3 -m http.server "$PORT" >/tmp/px-golf-camera-v2.log 2>&1 &
PID=$!
sleep 1
open "$URL"
echo "ブラウザで開きました。終了するときはこの画面を閉じてOK。"
echo "URL: $URL"
trap 'kill $PID 2>/dev/null || true' EXIT
wait $PID
