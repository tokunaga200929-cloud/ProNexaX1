const refs = {
  setup: document.getElementById('setupScreen'), camera: document.getElementById('cameraScreen'), review: document.getElementById('reviewScreen'),
  courseName: document.getElementById('courseName'), sideControl: document.getElementById('sideControl'), holeLabel: document.getElementById('holeLabel'), holeMinus: document.getElementById('holeMinus'), holePlus: document.getElementById('holePlus'), parInput: document.getElementById('parInput'), yardsInput: document.getElementById('yardsInput'), playerName: document.getElementById('playerName'), totalScore: document.getElementById('totalScore'), holeScore: document.getElementById('holeScore'), showScorecard: document.getElementById('showScorecard'),
  prevPlayer: document.getElementById('prevPlayer'), prevMeta: document.getElementById('prevMeta'), prevTotal: document.getElementById('prevTotal'), prevCourse: document.getElementById('prevCourse'), prevHole: document.getElementById('prevHole'), miniScorecard: document.getElementById('miniScorecard'),
  openCameraBtn: document.getElementById('openCameraBtn'), backSetupBtn: document.getElementById('backSetupBtn'), cameraVideo: document.getElementById('cameraVideo'), cameraFallback: document.getElementById('cameraFallback'),
  camPlayer: document.getElementById('camPlayer'), camMeta: document.getElementById('camMeta'), camMetaLine: document.getElementById('camMetaLine'), camHoleDots: document.getElementById('camHoleDots'), camTotal: document.getElementById('camTotal'), scoreCourse: document.getElementById('scoreCourse'), scorecardDom: document.getElementById('scorecardDom'), scoreGrid: document.getElementById('scoreGrid'), toggleScorecardBtn: document.getElementById('toggleScorecardBtn'), reopenScorecardBtn: document.getElementById('reopenScorecardBtn'),
  prevHoleBtn: document.getElementById('prevHoleBtn'), nextHoleBtn: document.getElementById('nextHoleBtn'), prevHoleText: document.getElementById('prevHoleText'), nextHoleText: document.getElementById('nextHoleText'), recordBtn: document.getElementById('recordBtn'), recordStatus: document.getElementById('recordStatus'), recordingTime: document.getElementById('recordingTime'), quickTotal: document.getElementById('quickTotal'), quickShot: document.getElementById('quickShot'), totalMinus: document.getElementById('totalMinus'), totalPlus: document.getElementById('totalPlus'), shotMinus: document.getElementById('shotMinus'), shotPlus: document.getElementById('shotPlus'),
  reviewVideo: document.getElementById('reviewVideo'), downloadLink: document.getElementById('downloadLink'), retakeBtn: document.getElementById('retakeBtn'), newShotBtn: document.getElementById('newShotBtn'), canvas: document.getElementById('recordCanvas'), supportPill: document.getElementById('supportPill'),
  topBarScale: document.getElementById('topBarScale'), scorecardScale: document.getElementById('scorecardScale'), topBarScaleLabel: document.getElementById('topBarScaleLabel'), scorecardScaleLabel: document.getElementById('scorecardScaleLabel')
};

const holes = {
  OUT:[
    {hole:1, par:4, yds:378, score:'4'}, {hole:2, par:3, yds:182, score:'3'}, {hole:3, par:4, yds:455, score:'4'},
    {hole:4, par:5, yds:512, score:''}, {hole:5, par:4, yds:392, score:''}, {hole:6, par:4, yds:410, score:''},
    {hole:7, par:3, yds:168, score:''}, {hole:8, par:5, yds:535, score:''}, {hole:9, par:4, yds:424, score:''}
  ],
  IN:[
    {hole:10, par:4, yds:401, score:''}, {hole:11, par:5, yds:548, score:''}, {hole:12, par:3, yds:176, score:''},
    {hole:13, par:4, yds:433, score:''}, {hole:14, par:4, yds:389, score:''}, {hole:15, par:5, yds:566, score:''},
    {hole:16, par:3, yds:198, score:''}, {hole:17, par:4, yds:417, score:''}, {hole:18, par:4, yds:442, score:''}
  ]
};
const scoreOptions=['-5','-4','-3','-2','-1','E','+1','+2','+3','+4','+5'];
let state = { side:'OUT', index:2, stream:null, recorder:null, chunks:[], recordTimer:null, recordStart:0, recordedUrl:null, mime:'video/webm', animationId:null };
const pxLogoImg = new Image();
pxLogoImg.src = 'assets/px-logo-badge.png';

function currentHole(){ return holes[state.side][state.index]; }
function showScreen(screen){ [refs.setup, refs.camera, refs.review].forEach(s=>s.classList.remove('active')); screen.classList.add('active'); document.body.classList.toggle('camera-active', screen===refs.camera); }
function totalScoreText(){ return refs.totalScore.value || 'E'; }
function setTotalByDelta(delta){ let i=scoreOptions.indexOf(totalScoreText()); if(i<0)i=5; i=Math.max(0,Math.min(scoreOptions.length-1,i+delta)); refs.totalScore.value=scoreOptions[i]; updateAll(); }
function setShotByDelta(delta){ const h=currentHole(); const cur = Number(refs.holeScore.value || h.score || h.par); const next = Math.max(1, Math.min(12, cur+delta)); refs.holeScore.value=String(next); h.score=String(next); updateAll(); }
function setHoleByIndex(idx){
  state.index = Math.max(0, Math.min(8, idx));
  const h=currentHole(); refs.holeLabel.textContent = `${h.hole}番`; refs.parInput.value = h.par; refs.yardsInput.value = h.yds; refs.holeScore.value = h.score || '';
  updateAll();
}
function updateHoleDataFromInputs(){ const h=currentHole(); h.par=Number(refs.parInput.value||h.par); h.yds=Number(refs.yardsInput.value||h.yds); h.score=refs.holeScore.value || ''; updateAll(); }
function updateAll(){
  const h=currentHole(); const name=(refs.playerName.value||'PLAYER').toUpperCase(); const course=refs.courseName.value || 'GOLF COURSE'; const meta=`HOLE ${h.hole}   PAR ${h.par}   ${h.yds} YDS`;
  refs.prevPlayer.textContent=name; refs.prevMeta.textContent=meta; refs.prevTotal.textContent=totalScoreText(); refs.prevCourse.textContent=course; refs.prevHole.textContent=h.hole;
  refs.camPlayer.textContent=name; refs.camMeta.textContent=meta; if(refs.camMetaLine) refs.camMetaLine.innerHTML=`HOLE ${h.hole} <i></i> PAR ${h.par} <i></i> ${h.yds} YDS`; refs.camTotal.textContent=totalScoreText(); refs.scoreCourse.textContent=course; renderBroadcastHoles();
  refs.quickTotal.textContent=totalScoreText(); refs.quickShot.textContent=h.score || '-';
  refs.scorecardDom.classList.toggle('hidden', !refs.showScorecard.checked); refs.reopenScorecardBtn.classList.toggle('show', !refs.showScorecard.checked);
  refs.prevHoleText.textContent = `HOLE ${holes[state.side][Math.max(0,state.index-1)].hole}`; refs.nextHoleText.textContent = `HOLE ${holes[state.side][Math.min(8,state.index+1)].hole}`;
  const topScale = (Number(refs.topBarScale?.value || 100) / 100).toFixed(2);
  const cardScale = (Number(refs.scorecardScale?.value || 100) / 100).toFixed(2);
  document.documentElement.style.setProperty('--topbar-scale', topScale);
  document.documentElement.style.setProperty('--scorecard-scale', cardScale);
  if(refs.topBarScaleLabel) refs.topBarScaleLabel.textContent = `${Math.round(topScale*100)}%`;
  if(refs.scorecardScaleLabel) refs.scorecardScaleLabel.textContent = `${Math.round(cardScale*100)}%`;
  renderScoreGrid(); renderMiniScorecard();
}


function renderBroadcastHoles(){
  if(!refs.camHoleDots) return;
  const nums = holes[state.side].map(h=>h.hole);
  let start = Math.max(0, Math.min(state.index - 2, nums.length - 5));
  const view = nums.slice(start, start + 5);
  refs.camHoleDots.innerHTML='';
  view.forEach((n)=>{
    const s=document.createElement('span');
    s.textContent = String(n);
    if(n===currentHole().hole) s.classList.add('active');
    refs.camHoleDots.appendChild(s);
  });
}

function renderScoreGrid(){
  const rows = [ ['HOLE', ...holes[state.side].map(h=>h.hole)], ['PAR', ...holes[state.side].map(h=>h.par)], ['YDS', ...holes[state.side].map(h=>h.yds)], ['SCORE', ...holes[state.side].map(h=>h.score||'-')] ];
  refs.scoreGrid.innerHTML='';
  rows.forEach((row, r)=> row.forEach((v, c)=>{ const d=document.createElement('div'); d.textContent=v; if(c===0)d.classList.add('label'); if(c===state.index+1 && r===0)d.classList.add('active-hole'); if(c===state.index+1 && r===3)d.classList.add('score-active'); if(r===2 && c>0)d.classList.add('yds'); refs.scoreGrid.appendChild(d); }));
}
function renderMiniScorecard(){
  refs.miniScorecard.innerHTML='';
  const row=['HOLE',...holes[state.side].map(h=>h.hole),'PAR',...holes[state.side].map(h=>h.par),'SCORE',...holes[state.side].map(h=>h.score||'-')];
  row.forEach((v, idx)=>{ const d=document.createElement('div'); d.textContent=v; const r=Math.floor(idx/10), c=idx%10; if(c===0)d.classList.add('lbl'); if(c===state.index+1 && r===0)d.classList.add('hi'); refs.miniScorecard.appendChild(d); });
}

function clampValue(v,min,max){ return Math.max(min, Math.min(max, v)); }
function setSlider(el, value){ if(!el) return; el.value = String(Math.round(clampValue(value, Number(el.min||0), Number(el.max||999)))); }
function setupOverlayResize(handle, type){
  if(!handle) return;
  handle.addEventListener('pointerdown', (e)=>{
    e.preventDefault();
    e.stopPropagation();
    handle.setPointerCapture?.(e.pointerId);
    const sx=e.clientX, sy=e.clientY;
    const startTopX=Number(refs.topBarScaleX?.value||100);
    const startTopY=Number(refs.topBarScaleY?.value||100);
    const startCardX=Number(refs.scorecardScaleX?.value||100);
    const startCardY=Number(refs.scorecardScaleY?.value||100);
    const move=(ev)=>{
      ev.preventDefault();
      const dx=ev.clientX-sx, dy=ev.clientY-sy;
      if(type==='top'){
        // 上バーは右上基準なので、左下ハンドルを左へ/下へ動かすと大きくなる
        setSlider(refs.topBarScaleX, startTopX + (-dx*0.38));
        setSlider(refs.topBarScaleY, startTopY + (dy*0.55));
      }else{
        // 下カードは右下方向へ引っ張ると大きくなる
        setSlider(refs.scorecardScaleX, startCardX + (dx*0.38));
        setSlider(refs.scorecardScaleY, startCardY + (dy*0.45));
      }
      updateAll();
    };
    const up=(ev)=>{
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      try{ handle.releasePointerCapture?.(e.pointerId); }catch(_){}
    };
    window.addEventListener('pointermove', move, {passive:false});
    window.addEventListener('pointerup', up, {passive:false});
  });
}
function lockCameraTouch(){
  window.addEventListener('touchmove', (e)=>{
    if(document.body.classList.contains('camera-active')) e.preventDefault();
  }, {passive:false});
}

function bind(){
  refs.sideControl.querySelectorAll('button').forEach(btn=>btn.addEventListener('click',()=>{ refs.sideControl.querySelectorAll('button').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); state.side=btn.dataset.side; state.index=state.side==='OUT'?2:0; setHoleByIndex(state.index); }));
  refs.holeMinus.onclick=()=>setHoleByIndex(state.index-1); refs.holePlus.onclick=()=>setHoleByIndex(state.index+1);
  refs.prevHoleBtn.onclick=()=>setHoleByIndex(state.index-1); refs.nextHoleBtn.onclick=()=>setHoleByIndex(state.index+1);
  [refs.courseName, refs.playerName, refs.totalScore, refs.holeScore, refs.parInput, refs.yardsInput, refs.showScorecard].forEach(el=>el.addEventListener('input', updateHoleDataFromInputs));
  [refs.topBarScale, refs.scorecardScale].forEach(el=> el && el.addEventListener('input', updateAll));
  refs.openCameraBtn.onclick=openCamera; refs.backSetupBtn.onclick=()=>showScreen(refs.setup);
  refs.toggleScorecardBtn.onclick=()=>{ refs.showScorecard.checked=false; updateAll(); };
  refs.reopenScorecardBtn.onclick=()=>{ refs.showScorecard.checked=true; updateAll(); };
  refs.totalMinus.onclick=()=>setTotalByDelta(-1); refs.totalPlus.onclick=()=>setTotalByDelta(1); refs.shotMinus.onclick=()=>setShotByDelta(-1); refs.shotPlus.onclick=()=>setShotByDelta(1);
  refs.recordBtn.onclick=()=> state.recorder && state.recorder.state==='recording' ? stopRecording() : startRecording();
  setupOverlayResize(refs.topBarDragHandle, 'top');
  setupOverlayResize(refs.scorecardDragHandle, 'card');
  lockCameraTouch();
  refs.retakeBtn.onclick=()=>showScreen(refs.camera);
  refs.newShotBtn.onclick=()=>{ setHoleByIndex(state.index+1); showScreen(refs.camera); };
}
async function openCamera(){
  showScreen(refs.camera); refs.cameraFallback.textContent='カメラ起動中...';
  try{
    if(state.stream) state.stream.getTracks().forEach(t=>t.stop());
    try{ state.stream = await navigator.mediaDevices.getUserMedia({ video:{ facingMode:{ ideal:'environment' }, width:{ideal:1080}, height:{ideal:1920} }, audio:true }); }
    catch(_){ state.stream = await navigator.mediaDevices.getUserMedia({ video:true, audio:true }); }
    refs.cameraVideo.srcObject=state.stream; refs.cameraFallback.style.display='none'; await refs.cameraVideo.play().catch(()=>{});
  }catch(err){ console.error(err); refs.cameraFallback.textContent='カメラを起動できませんでした。HTTPSかlocalhostで開いてください。'; alert('カメラを起動できませんでした。ブラウザのカメラ許可を確認してね。'); }
}
function bestMime(){ const list=['video/mp4;codecs="avc1.42E01E,mp4a.40.2"','video/mp4','video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm']; if(!window.MediaRecorder) return ''; return list.find(t=>MediaRecorder.isTypeSupported(t)) || ''; }
function setupSupport(){ const mime=bestMime(); state.mime=mime||'video/webm'; refs.supportPill.textContent = window.MediaRecorder ? ('Broadcast UI') : '録画非対応'; }
async function startRecording(){
  if(!window.MediaRecorder){ alert('このブラウザは録画に対応していません。Chrome / Safariの新しい版で試してね。'); return; }
  if(!state.stream){ await openCamera(); if(!state.stream) return; }
  state.chunks=[]; const canvas=refs.canvas; const canvasStream=canvas.captureStream(30); state.stream.getAudioTracks().forEach(t=>canvasStream.addTrack(t));
  try{ state.recorder = new MediaRecorder(canvasStream, state.mime ? {mimeType:state.mime} : undefined); } catch(e){ state.recorder = new MediaRecorder(canvasStream); }
  state.recorder.ondataavailable=e=>{ if(e.data && e.data.size) state.chunks.push(e.data); };
  state.recorder.onstop=onRecordingStop; state.recordStart=Date.now(); refs.recordBtn.classList.add('recording'); refs.recordStatus.textContent='録画中 00:00'; document.body.classList.add('is-recording');
  state.recordTimer=setInterval(()=>{ const s=Math.floor((Date.now()-state.recordStart)/1000); const label=`録画中 00:${String(s).padStart(2,'0')}`; refs.recordStatus.textContent=label; refs.recordingTime.textContent=`REC 00:${String(s).padStart(2,'0')}`; },250);
  drawLoop(); state.recorder.start(250);
}
function stopRecording(){ if(state.recorder && state.recorder.state==='recording') state.recorder.stop(); }
function onRecordingStop(){
  clearInterval(state.recordTimer); cancelAnimationFrame(state.animationId); refs.recordBtn.classList.remove('recording'); refs.recordStatus.textContent='撮影完了'; document.body.classList.remove('is-recording'); refs.recordingTime.textContent='REC 00:00';
  const type = state.recorder.mimeType || state.mime || 'video/webm'; const ext=type.includes('mp4')?'mp4':'webm'; const blob = new Blob(state.chunks,{type}); if(state.recordedUrl) URL.revokeObjectURL(state.recordedUrl); state.recordedUrl=URL.createObjectURL(blob);
  refs.reviewVideo.src=state.recordedUrl; refs.downloadLink.href=state.recordedUrl; refs.downloadLink.download=`px-golf-camera-hole-${currentHole().hole}-${Date.now()}.${ext}`; showScreen(refs.review);
}
function drawLoop(){ if(!state.recorder || state.recorder.state!=='recording') return; const c=refs.canvas, ctx=c.getContext('2d'); const W=c.width,H=c.height; ctx.clearRect(0,0,W,H); drawVideoCover(ctx, refs.cameraVideo, W, H); drawCanvasOverlay(ctx,W,H); state.animationId=requestAnimationFrame(drawLoop); }
function drawVideoCover(ctx, video, W, H){ if(video.videoWidth && video.videoHeight){ const vw=video.videoWidth, vh=video.videoHeight; const s=Math.max(W/vw,H/vh); const dw=vw*s, dh=vh*s; ctx.drawImage(video,(W-dw)/2,(H-dh)/2,dw,dh); }else{ const g=ctx.createLinearGradient(0,0,W,H); g.addColorStop(0,'#20452f'); g.addColorStop(1,'#07100c'); ctx.fillStyle=g; ctx.fillRect(0,0,W,H); } }
function roundRect(ctx,x,y,w,h,r){ const rr=Math.min(r,w/2,h/2); ctx.beginPath(); ctx.moveTo(x+rr,y); ctx.arcTo(x+w,y,x+w,y+h,rr); ctx.arcTo(x+w,y+h,x,y+h,rr); ctx.arcTo(x,y+h,x,y,rr); ctx.arcTo(x,y,x+w,y,rr); ctx.closePath(); }
function text(ctx,t,x,y,size,color='#fff',weight='800',align='left'){ ctx.font=`${weight} ${size}px -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif`; ctx.fillStyle=color; ctx.textAlign=align; ctx.textBaseline='middle'; ctx.fillText(String(t),x,y); }
function fitText(ctx,t,x,y,maxWidth,size,color='#fff',weight='900'){ let s=size; do{ ctx.font=`${weight} ${s}px -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif`; if(ctx.measureText(String(t)).width<=maxWidth) break; s-=2; }while(s>18); text(ctx,t,x,y,s,color,weight); }
function drawCanvasOverlay(ctx,W,H){
  const h=currentHole(), nameRaw=(refs.playerName.value||'PLAYER'), name=nameRaw.toLowerCase().replace(/\b\w/g, c=>c.toUpperCase()), score=totalScoreText();
  const topScale = Number(refs.topBarScale?.value || 100) / 100;
  const cardScale = Number(refs.scorecardScale?.value || 100) / 100;

  // compact broadcast bar, reference style
  const baseW = Math.min(760, W - 84);
  const logoW = 116;
  const topH = 70;
  const lowerH = 40;
  const scoreW = 74;
  const x = W - 42 - baseW;
  const y = 78;
  ctx.save();
  ctx.translate(x + baseW, y);
  ctx.scale(topScale, topScale);
  ctx.translate(-baseW, 0);
  ctx.shadowColor='rgba(0,0,0,.30)'; ctx.shadowBlur=18; ctx.shadowOffsetY=8;

  // logo block
  roundRect(ctx,0,0,logoW,topH,8);
  ctx.fillStyle='rgba(0,0,0,.92)'; ctx.fill();
  ctx.shadowColor='transparent';
  if(pxLogoImg.complete && pxLogoImg.naturalWidth){
    ctx.save();
    roundRect(ctx,0,0,logoW,topH,8); ctx.clip();
    ctx.drawImage(pxLogoImg,0,0,logoW,topH);
    ctx.restore();
  }else{
    text(ctx,'Px',logoW/2,topH/2,32,'#fff','1000','center');
  }

  // name bar
  const nameX = logoW;
  const nameW = baseW - logoW;
  roundRect(ctx,nameX,0,nameW,topH,0);
  const ng = ctx.createLinearGradient(nameX,0,nameX+nameW,0);
  ng.addColorStop(0,'rgba(58,58,58,.82)');
  ng.addColorStop(.55,'rgba(48,48,48,.72)');
  ng.addColorStop(1,'rgba(28,28,28,.62)');
  ctx.fillStyle=ng; ctx.fill();
  ctx.fillStyle='rgba(255,255,255,.09)'; ctx.fillRect(nameX,0,nameW,1);
  fitText(ctx,name,nameX+30,topH/2,nameW-scoreW-60,42,'#fff','900');

  // score box
  const sx = baseW - scoreW + 14;
  const sy = 13;
  roundRect(ctx,sx,sy,48,44,7);
  ctx.fillStyle='rgba(0,0,0,.92)'; ctx.fill();
  text(ctx,score,sx+24,sy+22,31,'#fff','1000','center');

  // lower strip: under the name bar only
  const lowerX = logoW;
  const lowerW = nameW;
  roundRect(ctx,lowerX,topH,lowerW,lowerH,0);
  ctx.fillStyle='rgba(24,24,24,.48)'; ctx.fill();
  ctx.strokeStyle='rgba(255,255,255,.08)'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(lowerX,topH); ctx.lineTo(lowerX+lowerW,topH); ctx.stroke();
  const metaY = topH + lowerH/2;
  text(ctx,`HOLE ${h.hole}`,lowerX+32,metaY,21,'rgba(255,255,255,.96)','700');
  text(ctx,`PAR ${h.par}`,lowerX+140,metaY,21,'rgba(255,255,255,.96)','700');
  text(ctx,`${h.yds} YDS`,lowerX+240,metaY,21,'rgba(255,255,255,.96)','700');
  const visible = holes[state.side].slice(Math.max(0, Math.min(state.index-2, holes[state.side].length-5)), Math.max(0, Math.min(state.index-2, holes[state.side].length-5)) + 5);
  const dotStart = lowerX + lowerW - 210;
  visible.forEach((hh,i)=>{
    const cx=dotStart+i*38;
    if(hh.hole===h.hole){ ctx.beginPath(); ctx.arc(cx,metaY,16,0,Math.PI*2); ctx.strokeStyle='rgba(255,255,255,.92)'; ctx.lineWidth=2.5; ctx.stroke(); }
    text(ctx,String(hh.hole),cx,metaY,20,'rgba(255,255,255,.96)','800','center');
  });
  ctx.restore();
  if(!refs.showScorecard.checked) return;
  const cardX=30, cardY=H-490, cardW=W-60, headH=68, rowH=46;
  const cardH = headH+rowH*4+8;
  ctx.save();
  ctx.translate(cardX, cardY + cardH);
  ctx.scale(cardScale, cardScale);
  ctx.translate(0, -cardH);
  roundRect(ctx,0,0,cardW,headH+rowH*4+8,30);
  const cg=ctx.createLinearGradient(0,0,0,headH+rowH*4); cg.addColorStop(0,'rgba(62,77,77,.40)'); cg.addColorStop(1,'rgba(14,22,21,.34)'); ctx.fillStyle=cg; ctx.fill(); ctx.clip();
  ctx.fillStyle='rgba(31,43,43,.42)'; ctx.fillRect(0,0,cardW,headH);
  fitText(ctx,refs.courseName.value||'GOLF COURSE',28,headH/2,cardW-180,24,'#fff','900');
  text(ctx,'スコアカード',cardW-30,headH/2,18,'rgba(255,255,255,.88)','900','right');
  const labels=['HOLE','PAR','YDS','SCORE']; const data=[holes[state.side].map(x=>x.hole), holes[state.side].map(x=>x.par), holes[state.side].map(x=>x.yds), holes[state.side].map(x=>x.score||'-')]; const labelW=106, cw=(cardW-labelW)/9;
  for(let r=0;r<4;r++){
    const yy=headH+r*rowH;
    ctx.fillStyle='rgba(255,255,255,.09)'; ctx.fillRect(0,yy,cardW,1);
    text(ctx,labels[r],22,yy+rowH/2,19,'rgba(255,255,255,.90)','1000','left');
    for(let i=0;i<9;i++){
      const xx=labelW+i*cw;
      if(r===0 && i===state.index){ ctx.fillStyle='rgba(255,255,255,.86)'; roundRect(ctx,xx+5,yy+5,cw-10,rowH-10,8); ctx.fill(); text(ctx,data[r][i],xx+cw/2,yy+rowH/2,20,'#111','1000','center'); }
      else { text(ctx,data[r][i],xx+cw/2,yy+rowH/2,r===2?16:21,'rgba(255,255,255,.94)','900','center'); if(r===3 && i===state.index){ ctx.strokeStyle='#86ff5f'; ctx.lineWidth=3; roundRect(ctx,xx+7,yy+6,cw-14,rowH-12,7); ctx.stroke(); } }
    }
  }
  ctx.restore();
}

bind(); setupSupport(); setHoleByIndex(2); updateAll();
